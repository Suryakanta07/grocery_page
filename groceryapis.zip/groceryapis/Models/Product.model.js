const mongoose = require("mongoose")
const schema = mongoose.schema

const ProductSchema = new Schema({
    name: {
        groceryItem: String,
        isPurchased: Boolean
    }
});

const Product = mongoose.model('Product', ProductSchema)
module.exports = Product;