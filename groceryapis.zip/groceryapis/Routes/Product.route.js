const express = require("express")
const router = express.Router()
const mongoose = require("mongoose")


router.get('/', (req,res,next) => {
    res.send('getting a list of all the products....')
});


router.post('/add', (req,res,next) => {
    
    let groceryList = new GroceryItem ({
        groceryItem : req.body.groceryItem,
        isPurchased : req.body.isPurchased

    });

    groceryList.save(function(err,groceryList) {
        if(err)
        res.send(err)
        else
        res.send({status: 200, message: 'Item Added Successfully'})
    });

});


router.get('/list', (req,res,next) => {
    
    
    GroceryItem.find(function(err,response) {
        if(err)
        res.send(err)
        else
        res.send({status: 200, product: response})
    });

});



router.put('/updateList', (req,res,next) => {
    const id =req.query.productId;
    
    GroceryItem.findByIdAndUpdate(id,function(err,response) {
        if(err)
        res.send(err)
        else
        res.send({status: 200, product: response})
    });

});



router.delete('/deleteList', (req,res,next) => {
    const id =req.query.productId;
    
    GroceryItem.findByIdAndDelete(id,function(err,response) {
        if(err)
        res.send(err)
        else
        res.send({status: 200, product: response})
    });

});

module.exports = router;