import React from 'react';
import CreateGrocery from "./components/CreateGrocery"
import "./App.css";

function App() {
  return (
    
  <div className = 'outer-box'>
  <>
    <h1>Monthly Grocery Planning App</h1>
    <h2>Plan for month of February</h2>
    </>
    <CreateGrocery />

  </div>
  );
}

export default App;
