import React,{useState} from 'react'
import "./GroceryList.css"


import { ListGroup } from 'react-bootstrap';

const GroceryList = (props) =>{
    const [checked, setChecked] = useState(false);
    return (
        <div > 
             
            <ListGroup >
               
                <ListGroup.Item className="a"> 
                
                     <input type="checkbox" 
                            name="checkbox" 
                            checked={checked}
                            onChange={() => setChecked(!checked)}  
                            className="checkBox"
                        /> 
                     <p style={{textDecoration: checked ? "line-through" : "" }} 
                               className="todoItems">{props.allTodos}
                     </p> 
                      
                     <i className="deleteItems" onClick= {()=> props.onClick(props.id)} class="fa fa-trash" aria-hidden="true"></i>
                    
                </ListGroup.Item>
            </ListGroup>  
        </div>
    )
}

export default GroceryList