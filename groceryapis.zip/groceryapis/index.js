const express = require("express");
const mongoose = require("mongoose");
//const Product = require('./Models/Product.model');
//const ProductRoute = require('./Routes/Product.route');

const app = express();

mongoose.connect('mongodb://localhost:27017/SK')
.then(()=> {
    console.log('mongoDB connected.....')
})


//var dbURL = require("./properties.js").DB_URL;

//mongoose.connect(dbURL);

/*mongoose.connection.on("connected", ()=> {
    console.log("Connected to mongoDB using mongoose");
});*/





//app.use('/products', ProductRoute);

app.listen(4000);